import { useState, useRef, useEffect, useCallback } from "react";
import { useTrip, ProfilePill, SuggestedAction, RESERVE_DESTINATIONS } from "./TripStore";
import { motion, AnimatePresence } from "motion/react";
import {
  Pencil, Check, X, AlertTriangle, Lightbulb, CheckCircle, Info,
  Play, Loader2, Zap,
} from "lucide-react";

// ── Action execution engine ──
// Simulates what an LLM would do: contextual actions with real workspace mutations.

function useActionExecutor() {
  const {
    setDestinations, updateProfilePill, addMessage, addInsight,
    setAgentStatus, setPhase, pushUndo, setExpandedDest, destinations,
  } = useTrip();

  const executeAction = useCallback((action: SuggestedAction) => {
    // Save state for undo BEFORE making changes
    pushUndo(action.label);

    setPhase("refining");
    setAgentStatus(`Executing: ${action.label}...`);

    const undoId = action.id;

    // Route to the right handler
    switch (action.id) {
      case "find-budget-destinations": {
        // Dismiss expensive ones, add budget-friendly reserves
        setTimeout(() => {
          setDestinations((prev) => {
            const kept = prev.map(d => {
              if (d.id === "santorini") return { ...d, dismissed: true };
              return d;
            });
            // Add Cartagena & Mexico City from reserves
            const cartagena = RESERVE_DESTINATIONS.find(d => d.id === "cartagena");
            const mexicoCity = RESERVE_DESTINATIONS.find(d => d.id === "mexico-city");
            const newDests = [...kept];
            if (cartagena && !kept.find(d => d.id === "cartagena")) newDests.push({ ...cartagena });
            if (mexicoCity && !kept.find(d => d.id === "mexico-city")) newDests.push({ ...mexicoCity });
            return newDests;
          });
          addMessage("agent",
            "I've made some changes to fit your new budget:\n\n" +
            "• Removed Santorini ($4.1k pp — too expensive)\n" +
            "• Added Cartagena ($1.8k pp) — Caribbean warmth with incredible food and colonial culture\n" +
            "• Added Mexico City ($1.5k pp) — world-class food scene, 5h direct flight, unbeatable value\n" +
            "• Kept Lisbon ($2.5k pp) and Bali ($3.2k pp, at the edge but possible)\n\n" +
            "All plans include full itineraries, flights, and hotels. You can undo this if it's not what you wanted.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
          setExpandedDest(null);
        }, 1500);
        break;
      }

      case "shorten-trips": {
        setTimeout(() => {
          updateProfilePill("duration", "5 days");
          setDestinations((prev) => prev.map(d => {
            if (d.dismissed) return d;
            // Trim itinerary to 5 days
            const trimmedItin = d.itinerary ? d.itinerary.slice(0, 5).map((day, i) => {
              if (i === 4) return { ...day, label: "Fly Home", items: ["Morning: last exploration", "Pack up & check out", "Airport transfer", "Fly home"] };
              return day;
            }) : undefined;
            // Adjust hotels
            const trimmedHotels = d.hotels?.map(h => ({ ...h, nights: Math.min(h.nights, 4) }));
            // Recalc cost estimate
            const costReduction = d.id === "bali" ? "$2.4k pp" : d.id === "santorini" ? "$3.2k pp" : d.id === "lisbon" ? "$1.9k pp" : d.cost;
            return {
              ...d,
              itinerary: trimmedItin,
              hotels: trimmedHotels,
              cost: costReduction,
              warnings: undefined, // clear old warnings
            };
          }));
          addMessage("agent",
            "I've shortened all trips from 7 days to 5 days to reduce costs:\n\n" +
            "• Bali: $3.2k → $2.4k pp (cut days 6-7, kept the highlights)\n" +
            "• Santorini: $4.1k → $3.2k pp (still over budget but closer)\n" +
            "• Lisbon: $2.5k → $1.9k pp (great value, removed beach day)\n\n" +
            "Duration updated to 5 days. Itineraries trimmed to keep the best experiences. You can undo this change.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
        }, 1200);
        break;
      }

      case "remove-incompatible": {
        setTimeout(() => {
          setDestinations((prev) => {
            const updated = prev.map(d => {
              if (d.warnings && d.warnings.length > 0) {
                return { ...d, dismissed: true };
              }
              return d;
            });
            // Add a reserve if we're running low
            const active = updated.filter(d => !d.dismissed);
            if (active.length < 2) {
              const cartagena = RESERVE_DESTINATIONS.find(r => r.id === "cartagena");
              if (cartagena && !updated.find(d => d.id === "cartagena")) {
                updated.push({ ...cartagena });
              }
            }
            return updated;
          });
          const removed = destinations.filter(d => d.warnings && d.warnings.length > 0 && !d.dismissed).map(d => d.name);
          addMessage("agent",
            `Removed ${removed.length} destination${removed.length > 1 ? "s" : ""} with compatibility issues: ${removed.join(", ")}. ` +
            (removed.length > 0 ? "I've added Cartagena as a budget-friendly alternative that matches your profile. " : "") +
            "You can undo this if you'd like them back.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
          setExpandedDest(null);
        }, 1000);
        break;
      }

      case "upgrade-hotels": {
        setTimeout(() => {
          setDestinations((prev) => prev.map(d => {
            if (d.dismissed) return d;
            const upgradedHotels = d.hotels?.map(h => {
              if (d.id === "bali") return { ...h, name: h.area === "Ubud" ? "Four Seasons Sayan" : "W Bali Seminyak", price: h.area === "Ubud" ? "$420/n" : "$380/n" };
              if (d.id === "santorini") return { ...h, name: "Canaves Oia Epitome", price: "$550/n" };
              if (d.id === "lisbon") return { ...h, name: "Bairro Alto Hotel", price: "$310/n" };
              return h;
            });
            return { ...d, hotels: upgradedHotels };
          }));
          addMessage("agent",
            "Hotels upgraded to luxury tier across all destinations:\n\n" +
            "• Bali: Four Seasons Sayan ($420/n) + W Seminyak ($380/n)\n" +
            "• Santorini: Canaves Oia Epitome ($550/n)\n" +
            "• Lisbon: Bairro Alto Hotel ($310/n)\n\n" +
            "Total trip costs have increased accordingly. You can undo this upgrade.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
        }, 1000);
        break;
      }

      case "replace-adventure": {
        setTimeout(() => {
          setDestinations((prev) => {
            const updated = prev.map(d => {
              if (d.id === "santorini") return { ...d, dismissed: true };
              return { ...d, warnings: undefined };
            });
            const cartagena = RESERVE_DESTINATIONS.find(r => r.id === "cartagena");
            if (cartagena && !updated.find(d => d.id === "cartagena")) {
              updated.push({ ...cartagena, score: 89, vibe: ["Culture", "Food", "Beach", "Adventure"] });
            }
            return updated;
          });
          addMessage("agent",
            "Swapped Santorini (scenic/romantic) for Cartagena which has much better adventure vibes:\n\n" +
            "• Snorkeling at Rosario Islands\n" +
            "• Street food exploration through Getsemaní\n" +
            "• Caribbean kayaking & island-hopping available\n\n" +
            "Bali and Lisbon kept — both have great adventure potential. You can undo this swap.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
          setExpandedDest(null);
        }, 1200);
        break;
      }

      case "add-family-activities": {
        setTimeout(() => {
          setDestinations((prev) => prev.map(d => {
            if (d.dismissed) return d;
            if (d.id === "santorini") return { ...d, dismissed: true };
            const familyActivities = d.activities ? [...d.activities] : [];
            if (d.id === "bali") {
              familyActivities.push(
                { name: "Bali Safari & Marine Park", day: 4, type: "Family", price: "$40", duration: "4h" },
                { name: "Waterbom water park", day: 5, type: "Family", price: "$35", duration: "5h" },
              );
            }
            if (d.id === "lisbon") {
              familyActivities.push(
                { name: "Lisbon Oceanarium", day: 2, type: "Family", price: "$25", duration: "3h" },
                { name: "Sintra fairy-tale palaces", day: 3, type: "Family", price: "$30", duration: "Full day" },
              );
            }
            return { ...d, activities: familyActivities, warnings: undefined };
          }));
          addMessage("agent",
            "Adjusted plans for family of 4:\n\n" +
            "• Removed Santorini (steep stairs, not kid-friendly)\n" +
            "• Added family activities to Bali: Safari Park, Waterbom water park\n" +
            "• Added family activities to Lisbon: Oceanarium, fairy-tale Sintra palaces\n" +
            "• All pricing recalculated for 4 travelers\n\n" +
            "You can undo this to go back to the couple's plan.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
          setExpandedDest(null);
        }, 1300);
        break;
      }

      case "focus-lisbon": {
        setTimeout(() => {
          setDestinations((prev) => prev.map(d => {
            if (d.id === "lisbon") return { ...d, pinned: true, score: 98, warnings: undefined };
            if (d.id !== "lisbon") return { ...d, dismissed: true };
            return d;
          }));
          setExpandedDest("lisbon");
          addMessage("agent",
            "Focused on Lisbon — your best match for a short trip:\n\n" +
            "• 7h direct flight (vs 20h Bali, 12h Santorini)\n" +
            "• Fits perfectly in 3-4 days\n" +
            "• Most walkable, no car needed\n\n" +
            "Other destinations hidden. You can undo to see all options again.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
        }, 1000);
        break;
      }

      case "combine-destinations": {
        setTimeout(() => {
          setDestinations((prev) => prev.map(d => {
            if (d.id === "lisbon") {
              const extendedItin = d.itinerary ? [...d.itinerary.slice(0, 5),
                { day: 6, label: "Fly to Santorini", items: ["Morning flight LIS → ATH (3.5h)", "Connect ATH → JTR (45min)", "Check in Oia", "First caldera sunset"] },
                { day: 7, label: "Caldera Day", items: ["Fira to Oia hike", "Wine tasting at Santo Wines", "Catamaran cruise", "Dinner at Ammoudi Bay"] },
                { day: 8, label: "Sea & History", items: ["Red Beach morning", "Ancient Akrotiri", "Afternoon at pool", "Farewell dinner at Selene"] },
                { day: 9, label: "Fly Home", items: ["Morning check-out", "Ferry to Athens", "Fly ATH → JFK"] },
              ] : undefined;
              return {
                ...d,
                name: "Lisbon + Santorini",
                hook: "Best of both — Lisbon's food & fado, then Santorini's caldera sunsets",
                cost: "$4.2k pp",
                itinerary: extendedItin,
                score: 95,
                warnings: undefined,
              };
            }
            if (d.id === "santorini") return { ...d, dismissed: true };
            return d;
          }));
          updateProfilePill("duration", "10-14 days");
          addMessage("agent",
            "Created a combined Lisbon + Santorini itinerary:\n\n" +
            "• Days 1-5: Lisbon (food, fado, Sintra, history)\n" +
            "• Day 6: Fly LIS → ATH → Santorini\n" +
            "• Days 7-8: Santorini highlights (caldera, wine, beaches)\n" +
            "• Day 9: Fly home via Athens\n\n" +
            "Total ~$4.2k pp. Duration updated to 10 days. You can undo to separate them.",
            undoId
          );
          setPhase("complete");
          setAgentStatus("");
          setExpandedDest("lisbon");
        }, 1500);
        break;
      }

      default: {
        setTimeout(() => {
          addMessage("agent", `I've noted your preference for "${action.label}". Adjusting plans accordingly...`);
          setPhase("complete");
          setAgentStatus("");
        }, 800);
      }
    }
  }, [setDestinations, updateProfilePill, addMessage, addInsight, setAgentStatus, setPhase, pushUndo, setExpandedDest, destinations]);

  return { executeAction };
}

// ── Simulated "LLM" that generates contextual actions based on profile changes ──

interface ProfileReaction {
  warnings: { destId: string; text: string }[];
  insights: { text: string; actions: SuggestedAction[] }[];
}

function generateReaction(key: string, value: string): ProfileReaction | null {
  const reactions: Record<string, Record<string, ProfileReaction>> = {
    budget: {
      "~$2-3k total": {
        warnings: [
          { destId: "santorini", text: "Santorini exceeds your new budget — $4.1k pp won't work." },
          { destId: "bali", text: "Bali is right at the edge at $3.2k pp. Consider shorter stay." },
        ],
        insights: [
          {
            text: "Budget reduced. Lisbon fits well, but others need changes. Here's what I'd suggest:",
            actions: [
              { id: "find-budget-destinations", label: "Find cheaper destinations", description: "Replace expensive options with budget-friendly alternatives like Cartagena and Mexico City", icon: "🔍" },
              { id: "shorten-trips", label: "Shorten to 5 days", description: "Reduce all trips from 7 to 5 days to cut costs ~30%", icon: "✂️" },
              { id: "remove-incompatible", label: "Remove over-budget trips", description: "Drop destinations that don't fit and find replacements", icon: "🗑️" },
            ],
          },
        ],
      },
      "~$5-8k total": {
        warnings: [],
        insights: [
          {
            text: "More budget room! I can enhance your options:",
            actions: [
              { id: "upgrade-hotels", label: "Upgrade all hotels", description: "Switch to luxury properties across all destinations", icon: "✨" },
              { id: "combine-destinations", label: "Combine Lisbon + Santorini", description: "Create a multi-city trip covering both for ~10 days", icon: "🔗" },
            ],
          },
        ],
      },
      "~$8k+ total": {
        warnings: [],
        insights: [
          {
            text: "Premium budget — you can go all out:",
            actions: [
              { id: "upgrade-hotels", label: "Upgrade to luxury", description: "Business class flights and 5-star properties everywhere", icon: "💎" },
              { id: "combine-destinations", label: "Multi-city itinerary", description: "Combine Lisbon + Santorini into one epic trip", icon: "🌍" },
            ],
          },
        ],
      },
    },
    vibe: {
      "Adventure, hiking, nature": {
        warnings: [
          { destId: "santorini", text: "Santorini is scenic/romantic — not great for adventure seekers." },
        ],
        insights: [
          {
            text: "Adventure vibe shift detected. Some destinations don't match:",
            actions: [
              { id: "replace-adventure", label: "Swap Santorini for adventure pick", description: "Replace with Cartagena — snorkeling, island-hopping, Caribbean adventure", icon: "🏔️" },
              { id: "remove-incompatible", label: "Remove mismatched trips", description: "Drop scenic-only destinations that lack adventure", icon: "🗑️" },
            ],
          },
        ],
      },
      "Relaxation, spa, beaches": {
        warnings: [
          { destId: "lisbon", text: "Lisbon is more of a city trip — beach access requires day trips." },
        ],
        insights: [
          {
            text: "Relaxation mode! Bali is perfect, but Lisbon's a stretch:",
            actions: [
              { id: "remove-incompatible", label: "Remove city-focused trips", description: "Drop destinations without great beach/spa access", icon: "🏖️" },
              { id: "find-budget-destinations", label: "Find more beach options", description: "Add tropical alternatives like Cartagena", icon: "🔍" },
            ],
          },
        ],
      },
    },
    who: {
      "Solo traveler": {
        warnings: [],
        insights: [
          {
            text: "Adjusted for solo travel. Pricing updated to single occupancy. Lisbon is especially great for solo trips.",
            actions: [],
          },
        ],
      },
      "Family (4)": {
        warnings: [
          { destId: "santorini", text: "Santorini can be tricky with kids — steep stairs, limited beaches." },
        ],
        insights: [
          {
            text: "Family trip! Some destinations need adjustments for kids:",
            actions: [
              { id: "add-family-activities", label: "Add family activities", description: "Replace adult-focused experiences with kid-friendly options", icon: "👨‍👩‍👧‍👦" },
              { id: "remove-incompatible", label: "Remove kid-unfriendly spots", description: "Drop destinations that aren't practical for families", icon: "🗑️" },
            ],
          },
        ],
      },
    },
    duration: {
      "3-4 days": {
        warnings: [
          { destId: "bali", text: "3-4 days is too short for Bali — 20h flight doesn't justify it." },
          { destId: "santorini", text: "Santorini in 3 days means missing half the experience." },
        ],
        insights: [
          {
            text: "Short trip! Long-haul destinations don't make sense:",
            actions: [
              { id: "focus-lisbon", label: "Focus on Lisbon only", description: "Lisbon is perfect for 3-4 days: direct 7h flight, walkable city", icon: "🎯" },
              { id: "remove-incompatible", label: "Remove long-haul trips", description: "Drop destinations that need 12+ hours of flying", icon: "✈️" },
              { id: "find-budget-destinations", label: "Find closer alternatives", description: "Add Mexico City or Cartagena — both under 6h flight", icon: "🔍" },
            ],
          },
        ],
      },
      "10-14 days": {
        warnings: [],
        insights: [
          {
            text: "Extended trip! You could combine multiple destinations:",
            actions: [
              { id: "combine-destinations", label: "Combine Lisbon + Santorini", description: "5 days Lisbon → 4 days Santorini, one epic trip", icon: "🔗" },
            ],
          },
        ],
      },
    },
  };

  return reactions[key]?.[value] || null;
}

// ── Components ──

const PROFILE_OPTIONS: Record<string, string[]> = {
  when: ["Mar 1–7", "Mar 8–14", "Mar 15–22", "Apr 1–8", "Flexible"],
  who: ["Solo traveler", "2 travelers", "Family (4)", "Group (6+)"],
  vibe: ["Warm, culture, food", "Adventure, hiking, nature", "Relaxation, spa, beaches", "Romance, wine, scenery"],
  budget: ["~$2-3k total", "~$3-5k total", "~$5-8k total", "~$8k+ total"],
  duration: ["3-4 days", "7 days", "10-14 days", "2+ weeks"],
};

function EditablePill({ pill }: { pill: ProfilePill }) {
  const { updateProfilePill, addInsight, setDestinations } = useTrip();
  const [editing, setEditing] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [customValue, setCustomValue] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setEditing(false);
        setShowOptions(false);
        setCustomValue("");
      }
    };
    if (editing) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [editing]);

  const handleSelect = (value: string) => {
    const oldValue = pill.value;
    if (value === oldValue) {
      setEditing(false);
      setShowOptions(false);
      return;
    }

    updateProfilePill(pill.key, value);
    setEditing(false);
    setShowOptions(false);
    setCustomValue("");

    // Generate contextual reaction
    const reaction = generateReaction(pill.key, value);
    if (reaction) {
      // Add warnings to destination cards
      if (reaction.warnings.length > 0) {
        setTimeout(() => {
          setDestinations((prev) =>
            prev.map((d) => {
              const warning = reaction.warnings.find((w) => w.destId === d.id);
              if (warning) return { ...d, warnings: [warning.text] };
              return { ...d, warnings: undefined };
            })
          );
        }, 300);
      } else {
        setTimeout(() => {
          setDestinations((prev) => prev.map(d => ({ ...d, warnings: undefined })));
        }, 300);
      }
      // Add insights with actions
      reaction.insights.forEach((ins, i) => {
        setTimeout(() => {
          addInsight(
            reaction.warnings.length > 0 ? "warning" : "tip",
            ins.text,
            undefined,
            ins.actions.length > 0 ? ins.actions : undefined,
          );
        }, 500 + i * 400);
      });
    } else {
      setTimeout(() => {
        addInsight("info", `Updated ${pill.label.toLowerCase()} to "${value}". All plans re-evaluated.`);
        setDestinations((prev) => prev.map(d => ({ ...d, warnings: undefined })));
      }, 300);
    }
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customValue.trim()) {
      handleSelect(customValue.trim());
    }
  };

  return (
    <div ref={ref} className="relative">
      <motion.button
        onClick={() => { setEditing(!editing); setShowOptions(!showOptions); }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={`flex items-center gap-2 w-full px-3 py-2 rounded-xl text-left transition-all ${
          editing
            ? "bg-indigo-500/15 border border-indigo-500/30"
            : "bg-white/[0.04] border border-white/[0.06] hover:border-white/[0.12] hover:bg-white/[0.06]"
        }`}
      >
        <span className="text-[14px]">{pill.icon}</span>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] text-white/30 uppercase tracking-wider">{pill.label}</p>
          <p className="text-[13px] text-white/80 truncate">{pill.value}</p>
        </div>
        <Pencil className="w-3 h-3 text-white/20 shrink-0" />
      </motion.button>

      <AnimatePresence>
        {showOptions && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.95 }}
            className="absolute top-full left-0 right-0 mt-1.5 z-50 bg-[#1a1a2e] border border-white/[0.1] rounded-xl overflow-hidden shadow-xl shadow-black/40"
          >
            {(PROFILE_OPTIONS[pill.key] || []).map((opt) => (
              <button
                key={opt}
                onClick={() => handleSelect(opt)}
                className={`w-full text-left px-3 py-2 text-[13px] transition-colors ${
                  opt === pill.value
                    ? "bg-indigo-500/20 text-indigo-300"
                    : "text-white/60 hover:bg-white/[0.06] hover:text-white/80"
                }`}
              >
                {opt}
                {opt === pill.value && <Check className="w-3 h-3 inline ml-2 text-indigo-400" />}
              </button>
            ))}
            
            {/* Custom input field for vibe */}
            {pill.key === "vibe" && (
              <form onSubmit={handleCustomSubmit} className="border-t border-white/[0.08] p-2">
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={customValue}
                    onChange={(e) => setCustomValue(e.target.value)}
                    placeholder="Or type your own vibe..."
                    className="flex-1 px-2.5 py-1.5 bg-white/[0.04] border border-white/[0.08] rounded-lg text-[12px] text-white/80 placeholder:text-white/30 focus:outline-none focus:border-indigo-500/40 focus:bg-white/[0.06]"
                    autoFocus={false}
                  />
                  <button
                    type="submit"
                    disabled={!customValue.trim()}
                    className="px-2.5 py-1.5 bg-indigo-500/20 border border-indigo-500/30 rounded-lg text-[11px] text-indigo-300 hover:bg-indigo-500/30 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    Set
                  </button>
                </div>
                <p className="text-[9px] text-white/20 mt-1 ml-0.5">Any keywords, the AI will understand</p>
              </form>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ActionButton({ action, onExecute }: { action: SuggestedAction; onExecute: () => void }) {
  const [loading, setLoading] = useState(false);

  const handleClick = () => {
    setLoading(true);
    onExecute();
    // Loading state auto-clears when the phase changes
    setTimeout(() => setLoading(false), 2000);
  };

  return (
    <motion.button
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      onClick={handleClick}
      disabled={loading}
      className="flex items-center gap-2 w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/[0.08] hover:bg-white/[0.08] hover:border-white/[0.14] transition-all text-left group disabled:opacity-50"
    >
      <span className="text-[13px] shrink-0">{action.icon}</span>
      <div className="flex-1 min-w-0">
        <p className="text-[12px] text-white/70 group-hover:text-white/90 transition-colors">{action.label}</p>
        <p className="text-[10px] text-white/30 leading-tight truncate">{action.description}</p>
      </div>
      {loading ? (
        <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin shrink-0" />
      ) : (
        <Play className="w-3 h-3 text-white/20 group-hover:text-indigo-400 transition-colors shrink-0" />
      )}
    </motion.button>
  );
}

function InsightCard({
  insight,
  onDismiss,
  onExecuteAction,
}: {
  insight: { id: string; type: string; text: string; actions?: SuggestedAction[] };
  onDismiss: () => void;
  onExecuteAction: (action: SuggestedAction) => void;
}) {
  const icons = {
    warning: <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />,
    tip: <Lightbulb className="w-3.5 h-3.5 text-indigo-400" />,
    success: <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />,
    info: <Info className="w-3.5 h-3.5 text-blue-400" />,
    comparison: <Info className="w-3.5 h-3.5 text-purple-400" />,
  };
  const borders = {
    warning: "border-amber-500/20 bg-amber-500/[0.06]",
    tip: "border-indigo-500/20 bg-indigo-500/[0.06]",
    success: "border-emerald-500/20 bg-emerald-500/[0.06]",
    info: "border-blue-500/20 bg-blue-500/[0.06]",
    comparison: "border-purple-500/20 bg-purple-500/[0.06]",
  };
  const hasActions = insight.actions && insight.actions.length > 0;
  const isLongContent = insight.text.length > 500; // Comparison texts are long

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -10 }}
      layout
      className={`rounded-xl border overflow-hidden ${borders[insight.type as keyof typeof borders] || borders.info}`}
    >
      {/* Message */}
      <div className="flex gap-2 px-3 py-2.5">
        <div className="shrink-0 mt-0.5">{icons[insight.type as keyof typeof icons] || icons.info}</div>
        <div 
          className={`flex-1 text-[12px] text-white/60 leading-relaxed ${
            isLongContent ? 'max-h-[400px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent' : ''
          }`}
        >
          {/* Render markdown-style content */}
          {insight.text.split('\n').map((line, i) => {
            // Headers
            if (line.startsWith('### ')) {
              return <h3 key={i} className="text-[13px] font-semibold text-white/80 mt-3 mb-1.5 first:mt-0">{line.replace('### ', '')}</h3>;
            }
            if (line.startsWith('#### ')) {
              return <h4 key={i} className="text-[12px] font-semibold text-white/75 mt-2.5 mb-1 first:mt-0">{line.replace('#### ', '')}</h4>;
            }
            if (line.startsWith('## ')) {
              return <h2 key={i} className="text-[14px] font-semibold text-white/90 mb-2 first:mt-0">{line.replace('## ', '')}</h2>;
            }
            // Bold text
            if (line.includes('**')) {
              const parts = line.split(/\*\*(.*?)\*\*/g);
              return (
                <p key={i} className="mb-1">
                  {parts.map((part, j) => 
                    j % 2 === 1 ? <strong key={j} className="text-white/80">{part}</strong> : part
                  )}
                </p>
              );
            }
            // Horizontal rule
            if (line === '---') {
              return <hr key={i} className="border-white/10 my-3" />;
            }
            // Bullet points
            if (line.startsWith('- ')) {
              return <p key={i} className="ml-3 mb-0.5">• {line.replace('- ', '')}</p>;
            }
            // Empty lines
            if (line.trim() === '') {
              return <div key={i} className="h-1" />;
            }
            // Regular text
            return <p key={i} className="mb-1">{line}</p>;
          })}
        </div>
        <button onClick={onDismiss} className="shrink-0 text-white/20 hover:text-white/40 mt-0.5">
          <X className="w-3 h-3" />
        </button>
      </div>

      {/* Suggested actions */}
      {hasActions && (
        <div className="px-2.5 pb-2.5 flex flex-col gap-1">
          <div className="flex items-center gap-1.5 px-1 mb-0.5">
            <Zap className="w-2.5 h-2.5 text-indigo-400" />
            <span className="text-[9px] text-white/25 uppercase tracking-widest">Suggested Actions</span>
          </div>
          {insight.actions!.map((action, i) => (
            <ActionButton
              key={action.id}
              action={action}
              onExecute={() => {
                onExecuteAction(action);
                onDismiss();
              }}
            />
          ))}
        </div>
      )}
    </motion.div>
  );
}

export function ProfilePanel() {
  const { profile, insights, dismissInsight } = useTrip();
  const { executeAction } = useActionExecutor();
  const activeInsights = insights.filter((i) => !i.dismissed).slice(-5);

  if (profile.length === 0) return null;

  return (
    <div className="flex flex-col gap-3">
      {/* Profile section */}
      <div>
        <div className="flex items-center gap-2 mb-2.5">
          <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
          <span className="text-[11px] text-white/30 uppercase tracking-widest">Traveler Profile</span>
        </div>
        <div className="flex flex-col gap-1.5">
          {profile.map((p) => (
            <EditablePill key={p.key} pill={p} />
          ))}
        </div>
      </div>

      {/* Agent insights with actions */}
      <AnimatePresence>
        {activeInsights.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-1"
          >
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="w-3 h-3 text-indigo-400" />
              <span className="text-[11px] text-white/30 uppercase tracking-widest">Advisor</span>
            </div>
            <div className="flex flex-col gap-2">
              <AnimatePresence>
                {activeInsights.map((insight) => (
                  <InsightCard
                    key={insight.id}
                    insight={insight}
                    onDismiss={() => dismissInsight(insight.id)}
                    onExecuteAction={executeAction}
                  />
                ))}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}