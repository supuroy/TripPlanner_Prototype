import { useTrip, type AgentResponse } from "./TripStore";
import { useRef, useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Bot, User, Lightbulb, AlertTriangle, CheckCircle, Info, X, Play, RotateCcw } from "lucide-react";

// Markdown parser - simple implementation
function parseMarkdown(text: string) {
  const lines = text.split("\n");
  const elements: JSX.Element[] = [];
  
  lines.forEach((line, idx) => {
    // H3 headers
    if (line.startsWith("### ")) {
      elements.push(
        <h3 key={idx} className="text-[15px] text-white/90 mt-4 mb-2">
          {line.replace("### ", "")}
        </h3>
      );
    }
    // H2 headers
    else if (line.startsWith("## ")) {
      elements.push(
        <h2 key={idx} className="text-[17px] text-white/95 mt-5 mb-3">
          {line.replace("## ", "")}
        </h2>
      );
    }
    // Horizontal rules
    else if (line.trim() === "---") {
      elements.push(
        <hr key={idx} className="border-white/[0.08] my-3" />
      );
    }
    // Bullet points
    else if (line.startsWith("- ")) {
      const content = line.replace("- ", "");
      // Process bold text **text**
      const parts = content.split(/(\*\*.*?\*\*)/g);
      
      elements.push(
        <div key={idx} className="flex gap-2 mb-1">
          <span className="text-white/30 mt-0.5">•</span>
          <span className="text-white/70 text-[13px] flex-1">
            {parts.map((part, i) => {
              if (part.startsWith("**") && part.endsWith("**")) {
                return (
                  <strong key={i} className="text-white/90">
                    {part.slice(2, -2)}
                  </strong>
                );
              }
              return <span key={i}>{part}</span>;
            })}
          </span>
        </div>
      );
    }
    // Regular paragraph
    else if (line.trim()) {
      // Process bold text **text**
      const parts = line.split(/(\*\*.*?\*\*)/g);
      
      elements.push(
        <p key={idx} className="text-white/70 text-[13px] mb-2 leading-relaxed">
          {parts.map((part, i) => {
            if (part.startsWith("**") && part.endsWith("**")) {
              return (
                <strong key={i} className="text-white/90">
                  {part.slice(2, -2)}
                </strong>
              );
            }
            return <span key={i}>{part}</span>;
          })}
        </p>
      );
    }
    // Empty line - just spacing
    else {
      elements.push(<div key={idx} className="h-2" />);
    }
  });
  
  return elements;
}

function ResponseCard({ response }: { response: AgentResponse }) {
  const { dismissResponse, performUndo, undoStack } = useTrip();
  const [isExpanded, setIsExpanded] = useState(false);
  
  // Determine styling based on type
  const getTypeConfig = () => {
    switch (response.type) {
      case "warning":
        return {
          icon: AlertTriangle,
          bgColor: "bg-amber-500/10",
          borderColor: "border-amber-500/20",
          iconColor: "text-amber-400",
        };
      case "success":
        return {
          icon: CheckCircle,
          bgColor: "bg-emerald-500/10",
          borderColor: "border-emerald-500/20",
          iconColor: "text-emerald-400",
        };
      case "tip":
      case "insight":
        return {
          icon: Lightbulb,
          bgColor: "bg-indigo-500/10",
          borderColor: "border-indigo-500/20",
          iconColor: "text-indigo-400",
        };
      case "destination_detail":
      case "comparison":
        return {
          icon: Info,
          bgColor: "bg-purple-500/10",
          borderColor: "border-purple-500/20",
          iconColor: "text-purple-400",
        };
      case "info":
        return {
          icon: Info,
          bgColor: "bg-blue-500/10",
          borderColor: "border-blue-500/20",
          iconColor: "text-blue-400",
        };
      case "message":
        return null; // Messages use different styling
    }
  };
  
  // Handle message type separately
  if (response.type === "message") {
    const isUser = response.role === "user";
    
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex ${isUser ? "justify-end" : "justify-start"} mb-3`}
      >
        <div className={`flex gap-3 max-w-[80%] ${isUser ? "flex-row-reverse" : ""}`}>
          {!isUser && (
            <div className="w-7 h-7 rounded-full bg-indigo-500/20 flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-indigo-400" />
            </div>
          )}
          
          <div className={`rounded-2xl px-4 py-2.5 ${
            isUser
              ? "bg-white/[0.08] text-white/80"
              : "bg-[#1a1a2e] text-white/70 border border-white/[0.06]"
          }`}>
            <p className="text-[13px] leading-relaxed whitespace-pre-wrap">
              {response.text}
            </p>
            
            {/* Undo button for agent messages with undoId */}
            {!isUser && response.undoId && (
              <button
                onClick={() => performUndo(response.undoId!)}
                className="flex items-center gap-1.5 mt-2 text-[11px] text-amber-400/70 hover:text-amber-400 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                Undo this change
              </button>
            )}
          </div>
          
          {isUser && (
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center flex-shrink-0 text-[11px] text-white">
              J
            </div>
          )}
        </div>
      </motion.div>
    );
  }
  
  // Handle insight/warning/success/tip/comparison types
  const config = getTypeConfig();
  if (!config) return null;
  
  const Icon = config.icon;
  const isComparison = response.type === "comparison";
  const isDestinationDetail = response.type === "destination_detail";
  const isExpandable = isComparison || isDestinationDetail;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-xl p-4 mb-4 ${config.bgColor} border ${config.borderColor} relative`}
    >
      {/* Close button */}
      <button
        onClick={() => dismissResponse(response.id)}
        className="absolute top-3 right-3 text-white/30 hover:text-white/60 transition-colors"
      >
        <X className="w-4 h-4" />
      </button>
      
      {/* Header */}
      <div className="flex items-start gap-3 mb-3">
        <Icon className={`w-5 h-5 ${config.iconColor} flex-shrink-0 mt-0.5`} />
        <div className="flex-1 pr-6">
          {isExpandable ? (
            <div>
              {/* Show preview or full content */}
              <div className={isExpanded ? "" : "max-h-[200px] overflow-hidden relative"}>
                {parseMarkdown(response.text)}
                
                {/* Fade overlay when collapsed */}
                {!isExpanded && (
                  <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-purple-500/10 to-transparent pointer-events-none" />
                )}
              </div>
              
              {/* Expand/Collapse button */}
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="mt-3 text-[12px] text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1.5"
              >
                {isExpanded ? (
                  <>
                    <span>Show less</span>
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                    </svg>
                  </>
                ) : (
                  <>
                    <span>{isDestinationDetail ? `Show full details` : `Show full comparison`}</span>
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </>
                )}
              </button>
            </div>
          ) : (
            <p className="text-white/80 text-[13px] leading-relaxed">
              {response.text}
            </p>
          )}
        </div>
      </div>
      
      {/* Suggested Actions */}
      {response.actions && response.actions.length > 0 && (
        <div className="mt-4 pt-4 border-t border-white/[0.08]">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-1 rounded-full bg-indigo-400" />
            <span className="text-[10px] text-white/40 uppercase tracking-wider">
              Suggested Actions
            </span>
          </div>
          
          <div className="space-y-2">
            {response.actions.map((action) => (
              <button
                key={action.id}
                className="w-full flex items-center gap-3 p-3 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] hover:border-white/[0.1] transition-all group"
              >
                <span className="text-lg">{action.icon}</span>
                <div className="flex-1 text-left">
                  <div className="text-[13px] text-white/90 mb-0.5">{action.label}</div>
                  <div className="text-[11px] text-white/40">{action.description}</div>
                </div>
                <Play className="w-4 h-4 text-indigo-400/60 group-hover:text-indigo-400 transition-colors" />
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Undo button if applicable */}
      {response.undoId && (
        <button
          onClick={() => performUndo(response.undoId!)}
          className="flex items-center gap-1.5 mt-3 text-[11px] text-amber-400/70 hover:text-amber-400 transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          Undo this change
        </button>
      )}
    </motion.div>
  );
}

export function AgentResponses() {
  const { responses } = useTrip();
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll to bottom on new response
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  }, [responses.length]);
  
  // Filter out dismissed responses
  const activeResponses = responses.filter(r => !r.dismissed);
  
  return (
    <div
      ref={scrollRef}
      className="h-full overflow-y-auto px-6 py-6 bg-[#0a0a0f]/50"
      style={{
        scrollbarWidth: "thin",
        scrollbarColor: "rgba(255,255,255,0.1) transparent",
      }}
    >
      {activeResponses.length === 0 ? (
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <Bot className="w-8 h-8 text-white/10 mx-auto mb-3" />
            <p className="text-white/20 text-[13px]">
              The agent will respond here...
            </p>
          </div>
        </div>
      ) : (
        <AnimatePresence>
          {activeResponses.map((response) => (
            <ResponseCard key={response.id} response={response} />
          ))}
        </AnimatePresence>
      )}
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.1);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255,255,255,0.15);
        }
      `}</style>
    </div>
  );
}