import { useState, useRef, useEffect } from "react";
import { useTrip, DESTINATIONS, RESERVE_DESTINATIONS } from "./TripStore";
import { motion, AnimatePresence } from "motion/react";
import { ArrowUp, Loader2 } from "lucide-react";
import type { DestCard } from "./TripStore";

const SUGGESTIONS = [
  "My partner and I want a warm beach trip in mid-March, about a week. We love food and culture.",
  "Solo adventure trip — hiking, surfing, somewhere tropical. Flexible on dates.",
  "Romantic anniversary getaway — somewhere scenic with great wine and food.",
];

export function CommandBar() {
  const {
    phase, setPhase, addMessage, setProfile, setDestinations,
    setAgentStatus, hasStarted, setHasStarted, destinations, setExpandedDest,
    addInsight, addResponse,
  } = useTrip();
  const [input, setInput] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!hasStarted) {
      const t = setTimeout(() => setShowSuggestions(true), 600);
      return () => clearTimeout(t);
    }
  }, [hasStarted]);

  const runAgent = (text: string) => {
    // Add user message to responses
    addResponse({ type: "message", role: "user", text });
    setHasStarted(true);
    setShowSuggestions(false);
    setInput("");

    // Check if this is a refinement message
    if (destinations.length > 0) {
      handleRefinement(text);
      return;
    }

    // Initial planning flow — everything happens in parallel
    setPhase("thinking");
    setAgentStatus("Understanding your trip...");

    // Step 1: Parse profile (fast)
    setTimeout(() => {
      setProfile([
        { key: "when", label: "When", value: "Mar 15–22", icon: "📅", editable: true },
        { key: "who", label: "Who", value: "2 travelers", icon: "👥", editable: true },
        { key: "vibe", label: "Vibe", value: "Warm, culture, food", icon: "✨", editable: true },
        { key: "budget", label: "Budget", value: "~$3-5k total", icon: "💰", editable: true },
        { key: "duration", label: "Duration", value: "7 days", icon: "⏱", editable: true },
      ]);
      setAgentStatus("Exploring destinations worldwide...");
      setPhase("streaming");
    }, 800);

    // Step 2: Stream destinations one by one
    setTimeout(() => {
      setAgentStatus("Found 3 perfect matches — building full plans for each...");
      addResponse({
        type: "message",
        role: "agent",
        text: "I found 3 destinations that match beautifully. I'm building complete itineraries, finding flights, and picking hotels for each — all at once. Here's what's materializing:"
      });
    }, 1600);

    // Stream cards in with staggered timing
    const dests = [...DESTINATIONS];
    dests.forEach((d, i) => {
      setTimeout(() => {
        setDestinations((prev) => [...prev, d]);
        if (i === 0) setAgentStatus("Building itineraries & finding flights...");
        if (i === 1) setAgentStatus("Comparing hotels & curating activities...");
        if (i === dests.length - 1) {
          setTimeout(() => {
            setPhase("complete");
            setAgentStatus("");
            addResponse({
              type: "message",
              role: "agent",
              text: "All plans are ready. Bali scores highest for your vibe — but Lisbon is a steal with a 7hr direct flight. Tap any card to dive in, or tell me what to adjust."
            });
            addResponse({
              type: "tip",
              text: "Try editing your traveler profile on the left to see how plans adjust in real-time."
            });
          }, 1200);
        }
      }, 2400 + i * 900);
    });
  };

  const handleRefinement = (text: string) => {
    setPhase("refining");
    const lower = text.toLowerCase();

    // Check for "tell me more about [destination]"
    if (lower.includes("tell me more") || lower.includes("more about") || (lower.includes("tell") && lower.includes("about"))) {
      // Try to find destination name in the query
      const dest = destinations.find(d => 
        !d.dismissed && lower.includes(d.name.toLowerCase())
      );
      
      if (!dest) {
        setAgentStatus("");
        addResponse({
          type: "message",
          role: "agent",
          text: "I'd love to tell you more! Which destination are you curious about? Try asking something like \"Tell me more about Bali\" or \"Tell me about Santorini\"."
        });
        setTimeout(() => {
          setPhase("complete");
        }, 500);
        return;
      }

      setAgentStatus(`Researching ${dest.name}...`);
      addResponse({
        type: "message",
        role: "agent",
        text: `Let me give you a comprehensive overview of ${dest.name}...`
      });
      
      setTimeout(() => {
        // Generate detailed destination information
        const detail = generateDestinationDetail(dest);
        addResponse({
          type: "destination_detail",
          text: detail,
          destinationId: dest.id,
          destinationName: dest.name
        });
        setAgentStatus("");
        setPhase("complete");
        
        // Add follow-up message
        setTimeout(() => {
          addResponse({
            type: "message",
            role: "agent",
            text: `That's ${dest.name} in a nutshell. Want to dive deeper into any specific aspect — food, activities, neighborhoods, or logistics? Just ask!`
          });
        }, 500);
      }, 2000);
      return;
    }

    // Check for "help me choose" when multiple destinations are pinned
    if ((lower.includes("help") && lower.includes("choose")) || 
        lower.includes("compare") || 
        lower.includes("which one") ||
        lower.includes("can't decide")) {
      const pinnedDests = destinations.filter(d => d.pinned && !d.dismissed);
      
      if (pinnedDests.length < 2) {
        setAgentStatus("");
        addResponse({
          type: "message",
          role: "agent",
          text: "I'd love to help you compare! But you'll need to pin at least 2 destinations first (click the pin icon on the cards). Once you've pinned your favorites, ask me again and I'll give you a detailed comparison."
        });
        setTimeout(() => {
          setPhase("complete");
        }, 500);
        return;
      }

      setAgentStatus("Analyzing your pinned destinations...");
      addResponse({
        type: "message",
        role: "agent",
        text: `Let me give you a comprehensive comparison of your ${pinnedDests.length} pinned options...`
      });
      
      setTimeout(() => {
        // Generate detailed comparison
        const comparison = generateComparison(pinnedDests);
        addResponse({
          type: "comparison",
          text: comparison
        });
        setAgentStatus("");
        setPhase("complete");
        
        // Add follow-up message
        setTimeout(() => {
          addResponse({
            type: "message",
            role: "agent",
            text: "That's my honest take based on your profile. What matters most to you — the experience, the budget, or the logistics? I can help you prioritize."
          });
        }, 500);
      }, 2000);
      return;
    }

    if (lower.includes("no") && lower.includes("greece") || lower.includes("no") && lower.includes("santorini") || lower.includes("remove") && lower.includes("santorini")) {
      setAgentStatus("Removing Santorini, adjusting recommendations...");
      addResponse({
        type: "message",
        role: "agent",
        text: "Got it — removing Santorini. That shifts more budget room. Want me to find another Mediterranean option, or double down on the tropical picks?"
      });
      setTimeout(() => {
        setDestinations((prev) => prev.map(d => d.id === "santorini" ? { ...d, dismissed: true } : d));
        setPhase("complete");
        setAgentStatus("");
      }, 1000);
    } else if (lower.includes("cheaper") || lower.includes("budget") || lower.includes("less expensive")) {
      setAgentStatus("Re-optimizing for lower budget...");
      addResponse({
        type: "message",
        role: "agent",
        text: "Shifting to budget-friendly options. Lisbon just jumped to #1 — direct flights under $650 and hotels at $195/night. I've also found cheaper hotel alternatives for Bali."
      });
      setTimeout(() => {
        setDestinations((prev) => prev.map(d => {
          if (d.id === "lisbon") return { ...d, score: 96 };
          return d;
        }));
        setPhase("complete");
        setAgentStatus("");
      }, 1200);
    } else if (lower.includes("bali") || lower.includes("go with") || lower.includes("let's do")) {
      setAgentStatus("Locking in Bali — finalizing everything...");
      addResponse({
        type: "message",
        role: "agent",
        text: "Bali it is! I've pinned it and expanded the full plan. Everything's ready — flights on Singapore Air, Bisma Eight in Ubud then The Legian on the coast, plus 6 curated activities. Total: ~$4,850 for two."
      });
      setTimeout(() => {
        setDestinations((prev) => prev.map(d => d.id === "bali" ? { ...d, pinned: true } : d));
        setExpandedDest("bali");
        setPhase("complete");
        setAgentStatus("");
      }, 1000);
    } else if (lower.includes("more") || lower.includes("other") || lower.includes("another") || lower.includes("add")) {
      setAgentStatus("Searching for more destinations...");
      addResponse({
        type: "message",
        role: "agent",
        text: "Looking for more options that match your style. I'll keep culture + food + warmth as the core criteria. Give me a moment..."
      });
      
      // Find destinations from reserves that aren't already added
      const currentIds = destinations.map(d => d.id);
      const availableReserves = RESERVE_DESTINATIONS.filter(r => !currentIds.includes(r.id));
      
      if (availableReserves.length === 0) {
        setTimeout(() => {
          setPhase("complete");
          setAgentStatus("");
          addResponse({
            type: "message",
            role: "agent",
            text: "I've already shown you all my best matches for your profile! If you'd like to see different options, try adjusting your traveler profile on the left (budget, vibe, duration, etc.) and I'll find new destinations that fit."
          });
        }, 1500);
        return;
      }
      
      // Add 2-3 new destinations
      const toAdd = availableReserves.slice(0, Math.min(3, availableReserves.length));
      
      setTimeout(() => {
        setAgentStatus(`Found ${toAdd.length} more options — building full plans...`);
        
        // Stream them in one by one
        toAdd.forEach((dest, i) => {
          setTimeout(() => {
            setDestinations((prev) => [...prev, dest]);
            
            if (i === toAdd.length - 1) {
              setTimeout(() => {
                setPhase("complete");
                setAgentStatus("");
                addResponse({
                  type: "message",
                  role: "agent",
                  text: `Added ${toAdd.map(d => d.name).join(", ")} to your workspace. ${toAdd[0].name} looks especially promising — similar vibes to what you liked, but ${toAdd[0].cost} per person. Tap any card to explore the full plan.`
                });
              }, 800);
            }
          }, 800 + i * 700);
        });
      }, 1500);
    } else {
      setAgentStatus("Adjusting plans...");
      addResponse({
        type: "message",
        role: "agent",
        text: "Noted! I'm factoring that in. All the plans are being re-evaluated. Anything specific you'd like me to change about the destinations, itineraries, or budget?"
      });
      setTimeout(() => {
        setPhase("complete");
        setAgentStatus("");
      }, 1000);
    }
  };

  const handleSubmit = () => {
    if (!input.trim() || phase === "thinking" || phase === "streaming") return;
    runAgent(input.trim());
  };

  const isWorking = phase === "thinking" || phase === "streaming" || phase === "refining";

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40">
      {/* Suggestions (only before start) */}
      <AnimatePresence>
        {showSuggestions && !hasStarted && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="max-w-2xl mx-auto px-6 mb-3"
          >
            <p className="text-[11px] text-white/30 mb-2 px-1 uppercase tracking-widest">Try saying</p>
            <div className="flex flex-col gap-2">
              {SUGGESTIONS.map((s, i) => (
                <motion.button
                  key={s}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => { setInput(s); inputRef.current?.focus(); }}
                  className="text-left px-4 py-2.5 rounded-xl bg-white/[0.05] border border-white/[0.08] text-white/50 text-[13px] hover:bg-white/[0.08] hover:text-white/70 transition-all backdrop-blur-sm"
                >
                  "{s}"
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Agent status */}
      <AnimatePresence>
        {isWorking && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="max-w-2xl mx-auto px-6 mb-2"
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/[0.05] backdrop-blur-md border border-white/[0.08] w-fit">
              <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
              <span className="text-[12px] text-white/50">{phase === "refining" ? "Adjusting..." : "Working..."}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input bar */}
      <div className="bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/95 to-transparent pt-6 pb-5 px-6">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 bg-white/[0.07] border border-white/[0.1] rounded-2xl px-5 py-3 backdrop-blur-xl focus-within:border-white/[0.2] transition-all">
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
              placeholder={hasStarted ? "Tell me what to change or refine..." : "Describe your dream trip..."}
              className="flex-1 bg-transparent text-white/90 placeholder:text-white/25 outline-none text-[15px]"
              disabled={phase === "thinking" || phase === "streaming"}
            />
            <button
              onClick={handleSubmit}
              disabled={!input.trim() || phase === "thinking" || phase === "streaming"}
              className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-white/40 hover:bg-white/20 hover:text-white/80 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            >
              {isWorking ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ArrowUp className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper function to generate a comprehensive comparison
function generateComparison(destinations: DestCard[]) {
  const sortedByScore = [...destinations].sort((a, b) => b.score - a.score);
  
  let comparison = `## Head-to-Head Comparison\n\n`;
  comparison += `You've pinned ${destinations.length} destinations. Let me break down how they stack up:\n\n`;
  
  // Quick summary table
  comparison += `### Quick Overview\n\n`;
  destinations.forEach((dest, idx) => {
    const bestFlight = dest.flights?.find(f => f.best) || dest.flights?.[0];
    const totalHotelCost = dest.hotels?.reduce((sum, h) => {
      const priceNum = parseInt(h.price.replace(/[^0-9]/g, ''));
      return sum + (priceNum * h.nights);
    }, 0) || 0;
    
    comparison += `**${idx + 1}. ${dest.name}, ${dest.country}** — ${dest.score}% match\n`;
    comparison += `- Flight: ${dest.flight} (${bestFlight?.price || 'TBD'})\n`;
    comparison += `- Hotels: ~$${totalHotelCost} total\n`;
    comparison += `- Vibe: ${dest.vibe.join(', ')}\n`;
    comparison += `- Temperature: ${dest.temp}\n\n`;
  });
  
  // Detailed analysis
  comparison += `### Detailed Analysis\n\n`;
  
  destinations.forEach((dest, idx) => {
    comparison += `#### ${dest.name}\n\n`;
    
    // Match score explanation
    if (dest.score >= 90) {
      comparison += `**Why it scores ${dest.score}%**: This is an exceptional match for your profile. `;
    } else if (dest.score >= 85) {
      comparison += `**Why it scores ${dest.score}%**: This aligns really well with what you're looking for. `;
    } else {
      comparison += `**Why it scores ${dest.score}%**: A solid option that hits most of your criteria. `;
    }
    
    // Vibe match
    comparison += `Your vibe (${dest.vibe.slice(0, 2).join(' + ')}) is everywhere here.\n\n`;
    
    // Logistics breakdown
    const bestFlight = dest.flights?.find(f => f.best) || dest.flights?.[0];
    comparison += `**Logistics**\n`;
    comparison += `- **Flight**: ${bestFlight?.airline || 'TBD'} (${bestFlight?.route || 'TBD'}), ${bestFlight?.duration || dest.flight} — ${bestFlight?.price || 'TBD'}\n`;
    
    if (dest.flights && dest.flights.length > 1) {
      comparison += `  - ${dest.flights.length} flight options available (ranging ${dest.flights[dest.flights.length - 1].price} – ${dest.flights[0].price})\n`;
    }
    
    comparison += `- **Temperature**: ${dest.temp} in mid-March\n`;
    comparison += `- **Time zone**: ${dest.flight.includes('20h') || dest.flight.includes('22h') ? 'Major jetlag (12+ hours)' : dest.flight.includes('12h') || dest.flight.includes('13h') ? 'Moderate jetlag (6-8 hours)' : 'Minimal jetlag'}\n\n`;
    
    // Budget breakdown
    comparison += `**Budget**\n`;
    if (dest.hotels) {
      dest.hotels.forEach(hotel => {
        const totalNights = hotel.nights;
        const pricePerNight = parseInt(hotel.price.replace(/[^0-9]/g, ''));
        const totalHotelCost = pricePerNight * totalNights;
        comparison += `- Hotel: ${hotel.name} (${hotel.area}) — ${hotel.price} × ${hotel.nights} nights = $${totalHotelCost}\n`;
      });
    }
    
    if (dest.activities) {
      const totalActivities = dest.activities.reduce((sum, a) => sum + parseInt(a.price.replace(/[^0-9]/g, '') || '0'), 0);
      comparison += `- Activities: ${dest.activities.length} curated experiences — ~$${totalActivities} total\n`;
    }
    
    const flightCost = parseInt(bestFlight?.price.replace(/[^0-9]/g, '') || '0');
    const hotelCost = dest.hotels?.reduce((sum, h) => sum + (parseInt(h.price.replace(/[^0-9]/g, '')) * h.nights), 0) || 0;
    const activityCost = dest.activities?.reduce((sum, a) => sum + parseInt(a.price.replace(/[^0-9]/g, '') || '0'), 0) || 0;
    const totalPerPerson = flightCost + hotelCost + activityCost;
    
    comparison += `- **Estimated total per person**: ~$${totalPerPerson.toLocaleString()} (×2 = ~$${(totalPerPerson * 2).toLocaleString()})\n\n`;
    
    // Experience highlights
    comparison += `**Experience Highlights**\n`;
    comparison += `${dest.hook}\n\n`;
    
    if (dest.itinerary) {
      const highlights = dest.itinerary.filter(day => day.accent || day.items.some(item => 
        item.toLowerCase().includes('sunset') || 
        item.toLowerCase().includes('unesco') ||
        item.toLowerCase().includes('cooking') ||
        item.toLowerCase().includes('trek') ||
        item.toLowerCase().includes('wine')
      )).slice(0, 3);
      
      if (highlights.length > 0) {
        comparison += `Key moments:\n`;
        highlights.forEach(day => {
          const standout = day.items.find(item => 
            item.toLowerCase().includes('sunset') || 
            item.toLowerCase().includes('trek') || 
            item.toLowerCase().includes('cooking') ||
            item.toLowerCase().includes('wine') ||
            item.toLowerCase().includes('cruise')
          ) || day.items[0];
          comparison += `- Day ${day.day}: ${standout}\n`;
        });
        comparison += `\n`;
      }
    }
    
    // Warnings
    if (dest.warnings && dest.warnings.length > 0) {
      comparison += `**⚠️ Heads up**: ${dest.warnings[0]}\n\n`;
    }
    
    comparison += `---\n\n`;
  });
  
  // Recommendation
  comparison += `### My Recommendation\n\n`;
  
  const topDest = sortedByScore[0];
  const budgetDest = [...destinations].sort((a, b) => {
    const aCost = parseInt(a.cost.replace(/[^0-9]/g, ''));
    const bCost = parseInt(b.cost.replace(/[^0-9]/g, ''));
    return aCost - bCost;
  })[0];
  
  const shortestFlight = [...destinations].sort((a, b) => {
    const aHours = parseInt(a.flight.replace(/[^0-9]/g, ''));
    const bHours = parseInt(b.flight.replace(/[^0-9]/g, ''));
    return aHours - bHours;
  })[0];
  
  if (destinations.length === 2) {
    comparison += `Between these two, here's my take:\n\n`;
    comparison += `- **If you prioritize the experience**: Go with **${topDest.name}** (${topDest.score}% match). It's the strongest fit for your vibe.\n`;
    comparison += `- **If budget matters most**: Choose **${budgetDest.name}** (${budgetDest.cost} per person vs ${topDest.id !== budgetDest.id ? topDest.cost : sortedByScore[1].cost}).\n`;
    comparison += `- **If you want easy logistics**: Pick **${shortestFlight.name}** (${shortestFlight.flight} flight vs ${topDest.id !== shortestFlight.id ? topDest.flight : sortedByScore[1].flight}).\n\n`;
  } else {
    comparison += `Looking at all ${destinations.length} options:\n\n`;
    comparison += `- **Best overall match**: **${topDest.name}** wins on vibes (${topDest.score}% score).\n`;
    comparison += `- **Best value**: **${budgetDest.name}** at ${budgetDest.cost} per person.\n`;
    comparison += `- **Easiest logistics**: **${shortestFlight.name}** with a ${shortestFlight.flight} flight.\n\n`;
  }
  
  comparison += `The real question: what matters more to you right now — having the most memorable experience, keeping costs down, or minimizing travel fatigue? Once you tell me, I can give you a clearer recommendation.`;
  
  return comparison;
}

// Helper function to generate detailed destination information
function generateDestinationDetail(dest: DestCard) {
  // Map destinations to rich contextual information
  const destinationInfo: Record<string, string> = {
    "bali": `## Bali, Indonesia

### The Essence

Bali is Indonesia's spiritual and cultural heart — a volcanic island where ancient Hindu temples sit among lush rice terraces, and the scent of incense mingles with frangipani. It's equal parts wellness retreat and adventure playground, with a deeply ingrained philosophy called "Tri Hita Karana" (harmony with nature, people, and spirit).

### Regions & Neighborhoods

- **Ubud**: The cultural center. Rice paddies, art galleries, yoga studios, and traditional dance. Stay here for immersion, not beaches.
- **Seminyak/Canggu**: The beach-club zone. Trendy cafes, surf breaks, sunset bars. Younger, more social.
- **Uluwatu**: Dramatic clifftop temples, pristine beaches accessible by stairs, luxury resorts. Quieter and more upscale.
- **Sanur**: The mellow beach town. Family-friendly, calm waters, traditional feel. Less party, more peace.

### Food Scene

Balinese cuisine is aromatic and complex — think **babi guling** (spit-roast suckling pig), **bebek betutu** (slow-cooked duck in spices), and **lawar** (minced meat salad with coconut). You'll also find incredible Indonesian staples like **nasi goreng** and **sate**. Ubud has a world-class plant-based scene (Alchemy, Sari Organik). Don't miss a traditional **warung** (family-run eatery) — they're authentic, delicious, and cheap.

### What Makes It Special

- **Temples**: Tanah Lot (ocean cliff), Uluwatu (sunset kecak dance), Besakih (mother temple on Mt. Agung)
- **Nature**: Tegallalang rice terraces, Mt. Batur sunrise trek, waterfalls (Tegenungan, Sekumpul)
- **Wellness**: World-renowned yoga, meditation, and spa culture. Ubud is the epicenter.
- **Ceremonies**: If you're lucky, you'll witness a Galungan or Kuningan ceremony — streets filled with offerings and processions

### Practical Notes

- **Best time**: April–October (dry season). March is shoulder season — warm, occasional rain.
- **Scooter culture**: Renting a scooter is the norm, but traffic in Seminyak/Canggu can be chaotic.
- **Visa**: Visa-on-arrival for most nationalities ($35 USD for 30 days)
- **Tipping**: Not expected, but appreciated. Small offerings ("canang sari") are placed everywhere — don't step on them.`,

    "santorini": `## Santorini, Greece

### The Essence

Santorini is a volcanic crescent in the Aegean Sea, famous for its whitewashed cave houses, blue-domed churches, and sunsets that feel almost religious. It's the remnant of a massive volcanic eruption 3,600 years ago, leaving behind the caldera — a submerged crater that creates the dramatic cliffside views.

### Regions & Neighborhoods

- **Oia**: The postcard village. Iconic sunset views, luxury cave hotels, high-end boutiques. Touristy but stunning.
- **Fira**: The capital. More bustling, with restaurants, shops, and cable car to the old port. Central and lively.
- **Imerovigli**: Quieter than Oia, still on the caldera. Romantic and upscale. Called the "balcony to the Aegean."
- **Pyrgos**: Inland village with medieval charm. Fewer tourists, authentic tavernas, panoramic views.
- **Kamari/Perissa**: Black-sand beach towns. More affordable, casual, beach-club vibes.

### Food Scene

Santorini's volcanic soil produces unique ingredients: **fava** (yellow split pea puree), **cherry tomatoes** (sweet and concentrated), **white eggplants**, and **Assyrtiko wine** (crisp, mineral-driven white). Must-tries: **tomatokeftedes** (tomato fritters), fresh seafood (grilled octopus, sea urchin), **moussaka**, and **baklava**. Wine tours are essential — Santo Wines and Venetsanos have caldera views.

### What Makes It Special

- **Sunsets**: Oia's sunset draws crowds (arrive early). Imerovigli and Skaros Rock offer quieter alternatives.
- **Wineries**: Volcanic terroir creates distinct wines. Visit Santo, Venetsanos, or Gavalas for tastings.
- **Archaeology**: Akrotiri (ancient Minoan city preserved in ash), Ancient Thera (cliffside ruins)
- **Beaches**: Red Beach (iron-rich cliffs), White Beach (accessible by boat), Kamari (black volcanic sand)

### Practical Notes

- **Best time**: May–June or September–October. March is early season — cooler (60–65°F), fewer tourists, some businesses closed.
- **Getting around**: Rent an ATV/car or use buses (cheap but infrequent). Taxis are expensive.
- **Caldera hotels**: Cave suites are iconic but pricey. Non-caldera hotels are 50–70% cheaper.
- **Crowds**: Cruise ships dump 5,000+ tourists daily in summer. Stay overnight to experience the magic.`,

    "lisbon": `## Lisbon, Portugal

### The Essence

Lisbon is a city of seven hills, colorful tiles (**azulejos**), and melancholic **fado** music echoing through cobblestone alleys. It's Europe's sunniest capital — a blend of old-world charm and modern creativity, where trams clatter up steep streets and the Tagus River glimmers gold at sunset.

### Regions & Neighborhoods

- **Alfama**: The oldest district. Narrow streets, fado houses, São Jorge Castle. Deeply atmospheric and historic.
- **Bairro Alto**: Nightlife central. Graffiti-covered walls, tiny bars, late-night energy. Bohemian and gritty.
- **Chiado**: The elegant heart. Bookstores, theaters, cafes (Café A Brasileira), high-street shopping. Cultured and refined.
- **Belém**: The monumental district. Jerónimos Monastery, Belém Tower, pastéis de nata at the source. Plan a half-day.
- **LX Factory**: A converted industrial complex. Street art, concept stores, rooftop bars. Creative and trendy.

### Food Scene

Portuguese cuisine is seafood-forward and soul-warming: **bacalhau** (salted cod, 1,000+ recipes), **sardines** (grilled, especially in June), **caldo verde** (kale soup), and **porco preto** (Iberian black pork). **Pastéis de nata** (custard tarts) are essential — Pastéis de Belém is the original, but locals argue smaller bakeries are better. Pair everything with **vinho verde** (young, slightly fizzy wine).

### What Makes It Special

- **Tram 28**: The iconic yellow tram rattles through Alfama and Graça. Touristy but fun. Go early or late.
- **Fado**: Hauntingly beautiful Portuguese blues. Catch a live show in Alfama (A Baiuca, Mesa de Frades).
- **Viewpoints (Miradouros)**: Portas do Sol, Santa Luzia, Graça, Senhora do Monte — each offers jaw-dropping vistas.
- **Day trips**: Sintra (fairytale palaces), Cascais (beach town), Óbidos (medieval walled village)

### Practical Notes

- **Best time**: March–May or September–October. March is lovely — 60°F, blooming jacarandas, fewer tourists.
- **Getting around**: Trams, metro, and walking. Buy a **Viva Viagem** card for public transit.
- **Safety**: Very safe, but watch for pickpockets on Tram 28 and in Rossio.
- **Language**: English is widely spoken in tourist areas. Learn "obrigado/a" (thank you).`,

    "tokyo": `## Tokyo, Japan

### The Essence

Tokyo is a city of contrasts — hyper-futuristic yet deeply traditional. Neon-soaked Shibuya Crossing exists minutes from serene Meiji Shrine. It's a place where Michelin-starred sushi masters work next to 7-Eleven stores selling gourmet convenience food, and vending machines offer everything from hot ramen to umbrellas.

### Regions & Neighborhoods

- **Shibuya**: Youth culture, fashion, nightlife. The iconic scramble crossing. Chaotic energy.
- **Shinjuku**: Skyscrapers, Tokyo Metropolitan Government Building (free observation deck), Golden Gai (tiny bars). Vast and neon-lit.
- **Asakusa**: Old Tokyo. Senso-ji Temple, traditional crafts, nostalgic streets. Grounded and historic.
- **Harajuku/Omotesando**: Takeshita Street (teen fashion chaos) vs. tree-lined Omotesando (high-end boutiques). Split personality.
- **Ginza**: Luxury shopping, department stores, art galleries. Polished and expensive.
- **Akihabara**: Otaku paradise. Electronics, anime, maid cafes. Niche but iconic.

### Food Scene

Tokyo has more Michelin stars than any city on Earth. **Sushi** (Tsukiji Outer Market, Sushi Dai), **ramen** (Ichiran, Afuri), **tonkatsu** (breaded pork cutlet), **yakitori** (grilled chicken skewers), **okonomiyaki** (savory pancake), and **kaiseki** (multi-course haute cuisine). Don't miss **depachika** (department store basements) for jaw-dropping food halls. Convenience stores (7-Eleven, Lawson) have legitimately great food.

### What Makes It Special

- **Temples & Shrines**: Senso-ji (Asakusa), Meiji Jingu (Harajuku), Nezu Shrine (vermillion gates)
- **Cherry blossoms**: Late March–early April. Ueno Park, Shinjuku Gyoen, Meguro River.
- **Teamlab Borderless/Planets**: Immersive digital art installations. Mind-bending and Instagram-famous.
- **Robot Restaurant**: Absurdly over-the-top dinner show. Love it or hate it, but uniquely Tokyo.

### Practical Notes

- **Best time**: March–May (cherry blossoms, mild) or October–November (fall colors). March is magical.
- **Getting around**: Subway/train system is world-class. Get a **Suica/Pasmo card** for tap-and-go transit.
- **Language barrier**: English signage is improving, but learning basic phrases helps. Google Translate's camera feature is a lifesaver.
- **Etiquette**: No tipping, no eating while walking, no phone calls on trains. Bow to show respect.`,

    "marrakech": `## Marrakech, Morocco

### The Essence

Marrakech assaults the senses in the best way — the call to prayer echoing over terracotta rooftops, the scent of spices and tagines, the labyrinth of souks where leather, lanterns, and carpets vie for attention. It's a medieval walled city that feels like stepping into a living, breathing bazaar from *One Thousand and One Nights*.

### Regions & Neighborhoods

- **Medina (Old City)**: The heart. Jemaa el-Fnaa square (snake charmers, storytellers, food stalls), souks (markets), riads (traditional courtyard homes). Overwhelming but essential.
- **Gueliz (Ville Nouvelle)**: The modern district. Wide boulevards, international brands, cafes. A breather from the Medina's intensity.
- **Palmeraie**: Date palm groves north of the city. Luxury resorts, golf courses, camel rides. Peaceful and resort-y.
- **Hivernage**: Upscale neighborhood near La Mamounia hotel. Nightclubs, gardens, more space.

### Food Scene

Moroccan cuisine is a symphony of spices — cumin, coriander, saffron, cinnamon. **Tagine** (slow-cooked stew in a clay pot: lamb with prunes, chicken with preserved lemons), **couscous** (Friday tradition), **pastilla** (sweet-savory pigeon pie), **harira** (lentil soup), and **mechoui** (spit-roast lamb). Mint tea is sacred — sweet, ceremonial, everywhere. Jemaa el-Fnaa's food stalls are an experience (grilled meats, snail soup), but for refined dining, hit Nomad or Le Jardin.

### What Makes It Special

- **Souks**: Get lost. Leather tanneries (Chouara), spice piles, metalwork, textiles. Haggle — it's expected.
- **Riads**: Stay in one. Traditional Moroccan homes with interior courtyards, often with rooftop terraces. Intimate and beautiful.
- **Majorelle Garden**: Yves Saint Laurent's cobalt-blue botanical garden. An oasis of calm. Adjacent Berber Museum.
- **Hammams**: Traditional Moroccan baths. Choose tourist-friendly (Les Bains de Marrakech) or authentic (local hammam — bring a friend as guide).

### Practical Notes

- **Best time**: March–May or September–November. March is pleasant — 70°F days, cool nights, blooming gardens.
- **Getting around**: Walk in the Medina, taxi outside (insist on meter or agree on price beforehand).
- **Dress code**: Modest clothing is respectful. Cover shoulders and knees, especially in conservative areas.
- **Haggling**: Expect to pay 40–60% of the initial asking price in souks. It's a game — enjoy it.`,

    "kyoto": `## Kyoto, Japan

### The Essence

Kyoto is Japan's cultural soul — the former imperial capital for over 1,000 years. It's a city of 2,000+ temples, Zen gardens, geisha districts, and tea ceremonies. Where Tokyo is neon and steel, Kyoto is wood and silk. Tradition isn't a museum here; it's a living, breathing practice.

### Regions & Neighborhoods

- **Gion**: The geisha district. Traditional machiya houses, teahouses, lantern-lit streets. Magical at dusk.
- **Arashiyama**: Bamboo groves, Tenryu-ji Temple, monkey park, scenic Togetsukyo Bridge. Nature meets culture.
- **Higashiyama**: Temple row. Kiyomizu-dera, Yasaka Shrine, Philosopher's Path. Historic and walkable.
- **Central (Kawaramachi/Shijo)**: Shopping, dining, modernity. A break from temple-hopping.
- **Fushimi**: Home to Fushimi Inari Shrine (10,000 red torii gates). Iconic and essential.

### Food Scene

Kyoto invented **kaiseki** (multi-course haute cuisine), perfected **matcha** (powdered green tea), and champions **shojin ryori** (Buddhist vegetarian cuisine). Must-tries: **yudofu** (tofu hot pot), **kyo-kaiseki** (seasonal tasting menus), **tsukemono** (pickled vegetables), and **yatsuhashi** (cinnamon rice sweets). Nishiki Market is "Kyoto's Kitchen" — sample everything. Tea ceremonies are meditative and delicious.

### What Makes It Special

- **Temples**: Kinkaku-ji (Golden Pavilion), Fushimi Inari (torii gates), Kiyomizu-dera (cliffside temple), Ryoan-ji (Zen rock garden)
- **Geisha culture**: Gion Corner for cultural shows; Maiko (apprentice geisha) spotting at dusk. Respectful distance, no photos unless invited.
- **Cherry blossoms**: Late March–early April. Maruyama Park, Philosopher's Path, Arashiyama. Ethereal.
- **Bamboo grove**: Arashiyama's towering green tunnel. Go at dawn to avoid crowds.

### Practical Notes

- **Best time**: March–May (cherry blossoms) or October–November (fall foliage). March is peak beauty.
- **Getting around**: Buses are extensive but confusing. Rent a bike or use trains. Kyoto Station is the hub.
- **Temple etiquette**: Remove shoes, bow before entering, no photos where prohibited. Silence in Zen gardens.
- **Crowds**: Over-tourism is real. Visit popular temples early morning or late evening.`,
  };

  return destinationInfo[dest.id] || `## ${dest.name}, ${dest.country}

### Overview

${dest.hook}

This destination offers incredible experiences for travelers seeking culture, adventure, and authentic local connections. Known for its unique blend of tradition and modernity, ${dest.name} captivates visitors with its vibrant atmosphere and welcoming spirit.

### What Makes It Special

${dest.name} stands out for its distinctive character and rich cultural heritage. Whether you're exploring historic neighborhoods, savoring local cuisine, or immersing yourself in daily life, you'll find countless moments that make this destination unforgettable.

### Practical Notes

- **Best time to visit**: Generally excellent year-round, with seasonal variations adding unique character
- **Getting around**: Mix of walking, local transit, and taxis/rideshare depending on the area
- **Local culture**: Immerse yourself in the destination's unique traditions and customs for the most authentic experience

*Want to know more about specific aspects like food, neighborhoods, or activities? Just ask!*`;
}