import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Send, X, MessageSquare, ChevronDown, Sparkles } from "lucide-react";
import { useTrip, type ConversationMessage } from "./TripStore";

interface ConversationPanelProps {
  destId: string;
  destName: string;
  mode: "minimized" | "footer" | "panel";
  onModeChange: (mode: "minimized" | "footer" | "panel") => void;
}

export function ConversationPanel({ destId, destName, mode, onModeChange }: ConversationPanelProps) {
  const { getConversation, addConversationMessage } = useTrip();
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const conversation = getConversation(destId);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversation]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput("");

    // Add user message
    addConversationMessage(destId, "user", userMessage);

    // If in minimized mode, switch to footer to show the response
    if (mode === "minimized") {
      onModeChange("footer");
    }

    // Simulate agent typing
    setIsTyping(true);

    // Generate mock response after delay
    setTimeout(() => {
      const response = generateMockResponse(userMessage, destName);
      addConversationMessage(destId, "agent", response);
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Render minimized (just input bar)
  if (mode === "minimized") {
    return (
      <div className="flex items-center gap-2 px-4 py-3 border-t border-white/[0.06] bg-black/20">
        <MessageSquare className="w-4 h-4 text-white/30" />
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask questions, request changes, or refine this plan..."
          className="flex-1 bg-transparent text-[13px] text-white placeholder:text-white/30 outline-none"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim()}
          className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center transition-all"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
        {conversation.length > 0 && (
          <button
            onClick={() => onModeChange("footer")}
            className="text-[11px] text-white/40 hover:text-white/60 transition-colors whitespace-nowrap"
          >
            See chat ({conversation.length})
          </button>
        )}
      </div>
    );
  }

  // Render footer (input + last message)
  if (mode === "footer") {
    const lastMessage = conversation[conversation.length - 1];

    return (
      <div className="border-t border-white/[0.06] bg-black/20">
        {/* Last message preview */}
        {lastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-4 py-2 border-b border-white/[0.04] cursor-pointer hover:bg-white/[0.02] transition-colors"
            onClick={() => onModeChange("panel")}
          >
            <div className="flex items-start gap-2">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400 mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-[12px] text-white/70 line-clamp-2">{lastMessage.text}</p>
              </div>
              <button className="text-[10px] text-white/30 hover:text-white/50 flex items-center gap-1 shrink-0">
                <span>Full thread</span>
                <ChevronDown className="w-3 h-3 -rotate-90" />
              </button>
            </div>
          </motion.div>
        )}

        {/* Input bar */}
        <div className="flex items-center gap-2 px-4 py-3">
          <MessageSquare className="w-4 h-4 text-white/30" />
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask a question or request a change..."
            className="flex-1 bg-transparent text-[13px] text-white placeholder:text-white/30 outline-none"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center transition-all"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onModeChange("minimized")}
            className="w-7 h-7 rounded-lg bg-white/[0.05] text-white/40 hover:text-white/60 hover:bg-white/[0.08] flex items-center justify-center transition-all"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  // Render panel (full conversation thread)
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="flex flex-col h-full border-l border-white/[0.06] bg-black/20"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/[0.06]">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-indigo-400" />
          <h3 className="text-[13px] text-white/80">Conversation</h3>
          <span className="text-[11px] text-white/30">({conversation.length})</span>
        </div>
        <button
          onClick={() => onModeChange("footer")}
          className="w-6 h-6 rounded-lg bg-white/[0.05] text-white/40 hover:text-white/60 hover:bg-white/[0.08] flex items-center justify-center transition-all"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {conversation.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Sparkles className="w-8 h-8 text-white/20 mb-2" />
            <p className="text-[12px] text-white/40">Start a conversation</p>
            <p className="text-[11px] text-white/25 mt-1">Ask questions or refine the itinerary</p>
          </div>
        ) : (
          <>
            {conversation.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-lg px-3 py-2 ${
                    msg.role === "user"
                      ? "bg-indigo-500/20 text-white/90 border border-indigo-500/30"
                      : "bg-white/[0.05] text-white/80 border border-white/[0.06]"
                  }`}
                >
                  {msg.role === "agent" && (
                    <div className="flex items-center gap-1.5 mb-1">
                      <Sparkles className="w-3 h-3 text-indigo-400" />
                      <span className="text-[10px] text-white/40">Wanderly</span>
                    </div>
                  )}
                  <p className="text-[12px] leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                </div>
              </motion.div>
            ))}
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="max-w-[85%] rounded-lg px-3 py-2 bg-white/[0.05] border border-white/[0.06]">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Sparkles className="w-3 h-3 text-indigo-400" />
                    <span className="text-[10px] text-white/40">Wanderly</span>
                  </div>
                  <div className="flex gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input area */}
      <div className="border-t border-white/[0.06] px-4 py-3 bg-black/10">
        <div className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask a question or refine the plan..."
            rows={2}
            className="flex-1 bg-white/[0.05] border border-white/[0.08] rounded-lg px-3 py-2 text-[12px] text-white placeholder:text-white/30 outline-none resize-none focus:border-indigo-500/30 transition-colors"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="w-9 h-9 rounded-lg bg-indigo-500 text-white hover:bg-indigo-600 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center transition-all shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-[10px] text-white/25 mt-2">Press Enter to send, Shift+Enter for new line</p>
      </div>
    </motion.div>
  );
}

// Mock response generator
function generateMockResponse(userMessage: string, destName: string): string {
  const lower = userMessage.toLowerCase();

  // Weather & Climate
  if (lower.includes("weather") || lower.includes("temperature") || lower.includes("climate") || lower.includes("rain")) {
    return `${destName} has a tropical climate with warm temperatures year-round. The best time to visit is typically during the dry season. I can adjust the itinerary to avoid rainy periods if you'd like.`;
  }

  // Food & Dining
  if (lower.includes("food") || lower.includes("restaurant") || lower.includes("eat") || lower.includes("dining")) {
    return `Great question! ${destName} has an incredible food scene. I've included some must-try local dishes in your itinerary. Would you like me to add more specific restaurant recommendations or food tours?`;
  }

  // Budget & Cost
  if (lower.includes("budget") || lower.includes("cost") || lower.includes("price") || lower.includes("cheaper") || lower.includes("expensive")) {
    return `I can help adjust the budget! There are several ways to reduce costs: choosing different accommodation, adjusting activities, or modifying travel dates. Which aspect would you like me to focus on?`;
  }

  // Hotels & Accommodation
  if (lower.includes("hotel") || lower.includes("accommodation") || lower.includes("stay") || lower.includes("where to sleep")) {
    return `I've selected hotels that balance location, quality, and value. Would you like me to suggest more affordable options, upgrade to luxury properties, or focus on a different neighborhood?`;
  }

  // Day-specific changes
  if (lower.match(/day\s*\d+/) || lower.includes("first day") || lower.includes("last day")) {
    const dayMatch = lower.match(/day\s*(\d+)/);
    const dayNum = dayMatch ? dayMatch[1] : "that";
    return `I can definitely modify Day ${dayNum}! What would you like to change? I can swap activities, adjust the pace, add more free time, or completely redesign the day based on your preferences.`;
  }

  // Activity changes
  if (lower.includes("activity") || lower.includes("activities") || lower.includes("thing to do")) {
    return `I can adjust the activities to better match your interests. Would you like more cultural experiences, outdoor adventures, relaxation time, or a different balance? I can also add or remove specific activities.`;
  }

  // Pace & Timing
  if (lower.includes("pace") || lower.includes("rushed") || lower.includes("slow") || lower.includes("relax") || lower.includes("free time")) {
    return `I can adjust the pacing! Would you like me to add more downtime, reduce the number of activities per day, or spread things out differently? Many travelers prefer a more relaxed pace with built-in flexibility.`;
  }

  // General changes
  if (lower.includes("change") || lower.includes("modify") || lower.includes("different") || lower.includes("instead") || lower.includes("swap")) {
    return `I'd be happy to modify the itinerary! Can you tell me specifically what you'd like to change? For example, swap a day activity, change hotels, adjust the pace, or focus on different experiences?`;
  }

  // Transportation
  if (lower.includes("transport") || lower.includes("getting around") || lower.includes("how to get") || lower.includes("travel between")) {
    return `For getting around ${destName}, I recommend a mix of local transport and private transfers depending on the day. I can add detailed transportation notes to each day of your itinerary if that would be helpful.`;
  }

  // Family-friendly
  if (lower.includes("kid") || lower.includes("child") || lower.includes("family") || lower.includes("toddler") || lower.includes("baby")) {
    return `I can definitely adapt this itinerary for families! I'll adjust activities to be more kid-friendly and suggest accommodation with family amenities. How old are the children traveling?`;
  }

  // Neighborhoods & Areas
  if (lower.includes("neighborhood") || lower.includes("area") || lower.includes("district") || lower.includes("where to stay")) {
    return `${destName} has several distinct neighborhoods, each with its own character. Based on your vibe, I've chosen areas that balance convenience, atmosphere, and local flavor. Want me to explain the different areas or suggest alternatives?`;
  }

  // Culture & History
  if (lower.includes("culture") || lower.includes("history") || lower.includes("tradition") || lower.includes("local")) {
    return `${destName} has a rich cultural heritage! I've woven in some authentic experiences, but I can add more temples, museums, traditional ceremonies, or local interactions if that's what you're after.`;
  }

  // Default response
  return `That's a great point about ${destName}! Let me look into that for you. Based on your current itinerary, I'd suggest keeping an eye on timing for Day 3 and Day 5. Would you like me to make any specific adjustments?`;
}
